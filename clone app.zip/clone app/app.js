var map = L.map('map').setView([30.3753, 69.3451], 6);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: 'Map data &copy; OpenStreetMap contributors'
}).addTo(map);

var provinceLayer, divisionLayer, districtLayer;
var provinceSelect = document.getElementById('provinceSelect');
var divisionSelect = document.getElementById('divisionSelect');
var districtSelect = document.getElementById('districtSelect');
var resetButton = document.getElementById('resetButton');

// Fetch and load Province data
$.ajax({
  url: 'http://localhost:8082/geoserver/india/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=india%3Apak_province&maxFeatures=5000&outputFormat=application%2Fjson',
  dataType: 'json',
  success: function(data) {
    var provinces = data.features;
    provinces.forEach(function(province) {
      var provinceName = province.properties.name_1;
      var option = document.createElement('option');
      option.value = provinceName;
      option.textContent = provinceName;
      provinceSelect.appendChild(option);
    });
  }
});

// Province selection event listener
provinceSelect.addEventListener('change', function() {
  var selectedProvince = provinceSelect.value;

  // Remove previous options
  divisionSelect.innerHTML = '';
  districtSelect.innerHTML = '';

  // Fetch and load Division data based on selected province
  $.ajax({
    url: 'http://localhost:8082/geoserver/india/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=india%3Apak_state&maxFeatures=5000&outputFormat=application%2Fjson',
    dataType: 'json',
    success: function(data) {
      var divisions = data.features.filter(function(division) {
        return division.properties.name_1 === selectedProvince;
      });
      divisions.forEach(function(division) {
        var divisionName = division.properties.name_2;
        var option = document.createElement('option');
        option.value = divisionName;
        option.textContent = divisionName;
        divisionSelect.appendChild(option);
      });

      // Select the first option by default
      divisionSelect.selectedIndex = 0;

      // Trigger the division selection event
      divisionSelect.dispatchEvent(new Event('change'));
    }
  });
});

// Division selection event listener
divisionSelect.addEventListener('change', function() {
  var selectedDivision = divisionSelect.value;

  // Remove previous options
  districtSelect.innerHTML = '';

  // Fetch and load District data based on selected division
  $.ajax({
    url: 'http://localhost:8082/geoserver/pk/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=pk%3APAK_adm3&maxFeatures=5000&outputFormat=application%2Fjson',
    dataType: 'json',
    success: function(data) {
      var districts = data.features.filter(function(district) {
        return district.properties.NAME_1 === provinceSelect.value &&
               district.properties.NAME_2 === selectedDivision;
      });
      districts.forEach(function(district) {
        var districtName = district.properties.NAME_3;
        var option = document.createElement('option');
        option.value = districtName;
        option.textContent = districtName;
        districtSelect.appendChild(option);
      });

      // Select the first option by default
      districtSelect.selectedIndex = 0;

      // Trigger the district selection event
      districtSelect.dispatchEvent(new Event('change'));
    }
  });
});

// District selection event listener
districtSelect.addEventListener('change', function() {
  var selectedDistrict = districtSelect.value;

  // Fetch and display the selected district on the map
  $.ajax({
    url: 'http://localhost:8082/geoserver/pk/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=pk%3APAK_adm3&maxFeatures=5000&outputFormat=application%2Fjson',
    dataType: 'json',
    success: function(data) {
      var district = data.features.find(function(feature) {
        return feature.properties.NAME_1 === provinceSelect.value &&
               feature.properties.NAME_2 === divisionSelect.value &&
               feature.properties.NAME_3 === selectedDistrict;
      });

      // Clear previous district layer
      if (districtLayer) {
        map.removeLayer(districtLayer);
      }

      // Add the selected district layer to the map
      districtLayer = L.geoJSON(district).addTo(map);

      // Fit the map to the bounds of the district layer
      map.fitBounds(districtLayer.getBounds());
    }
  });
});

// Reset button event listener
resetButton.addEventListener('click', function() {
  // Clear all dropdowns
  provinceSelect.value = '';
  divisionSelect.innerHTML = '';
  districtSelect.innerHTML = '';

  // Remove district layer from the map
  if (districtLayer) {
    map.removeLayer(districtLayer);
  }
});

// Fit the map view to the bounds of Pakistan
map.fitBounds([[23.6345, 60.872], [37.0841, 77.8375]]);
